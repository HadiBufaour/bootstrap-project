/*global $*/
$(document).ready(function () {
    
    'use strict';
    
    $(".carousel").carousel({
        interval : 6000
    });
    
});